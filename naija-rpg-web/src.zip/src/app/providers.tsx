'use client';

import { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { SessionBootstrap } from '@/components/system/SessionBootsrap';
import { SocketBridge } from '@/components/system/SocketBridge';

export function Providers({ children }: { children: React.ReactNode }) {
  const [client] = useState(
    () => new QueryClient({ defaultOptions: { queries: { staleTime: 15_000, retry: 1, refetchOnWindowFocus: false } } }),
  );
  return (
    <QueryClientProvider client={client}>
      <SessionBootstrap />
      <SocketBridge />
      {children}
    </QueryClientProvider>
  );
}