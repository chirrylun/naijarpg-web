'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { Card } from '@/components/ui/Card';
import { fillNames } from '@/lib/narrative';
import { useSession } from '@/stores/session';
import { Twists } from './StoryBits';
import type { RoomState } from '@/types';

export function ScenarioCard({ room }: { room: RoomState }) {
  const myId = useSession((s) => s.session?.user.id);
  const scene = room.scene;
  if (!scene) return null;
  return (
    <AnimatePresence mode="wait">
      <motion.div key={`${scene.key}:${room.round}`} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
        <Card>
          <p className="text-xs font-bold uppercase tracking-wider text-mute">{room.scenario.title}</p>
          <h2 className="mt-1 font-display text-2xl font-extrabold">{fillNames(scene.title, room, myId)}</h2>
          <p className="mt-2 leading-relaxed text-ink/90">{fillNames(scene.text, room, myId)}</p>
          {scene.stakes && (
            <div className="mt-3 flex items-start gap-2 rounded-xl bg-brand/10 px-3 py-2 text-sm">
              <span aria-hidden className="mt-0.5 text-brand">✦</span>
              <p className="text-ink/90">{fillNames(scene.stakes, room, myId)}</p>
            </div>
          )}
          <Twists lines={(scene.twists ?? []).slice(0, 1).map((l) => fillNames(l, room, myId))} />
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}